const { type } = require('express/lib/response')
const mongoose = require('mongoose');


//schema
const userSchema = new mongoose.Schema({
    fname: {
        type: String,
        required: [true, 'Name is required']
    },
    lname: {
        type: String,
        required: false
    },
    loginId: {
        type: String,
        required: [true, 'Email or phoneno is requied'],
        unique: true
    },
    password: {
        type: String,
        required: [true, 'Password is required']
    },
    cpassword: {
        type: String,
        required: false
    },
    address: {
        type: Array
    },
    usertype: {
        type: String,
        required: [true, 'user type is required'],
        default: 'customer',
        enum: ['customer','client', 'admin', 'vendor', 'driver','customercare']
    },
    orders:{
        type:String,
        require:false
    },
    wishlist:{
        type:String,
        require:false
    },
    orders:{
        type:String,
        require:false
    },
    support:{
        type:String,
        require:false
    },
    
},
{ timestamps: true })

//export
module.exports = mongoose.model('userData', userSchema);
document.getElementById("loginButton").addEventListener("click", function(){
    const uid = document.getElementById("loginId").value.trim();
    if (uid) {
        console.log(uid);
    }
});

document.getElementById('checkBox').addEventListener("click", function(){
    const pw = document.getElementById("pw");
    const cpw = document.getElementById("cpw");
    if (pw.type === "password"||cpw.type === "password") {
        pw.type = "text";
        cpw.type = "text";
    }else{
        pw.type = "password";
        cpw.type = "password";
    }
})

document.getElementById('loginForm').addEventListener('click', function(){
    this.classList.add('typing');
})
const userModel = require("../models/userModel")
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

//register
const registerController = async (req, res) => {
    try {
        const { fname, lname, loginId, password, cpassword} = req.body
        //validation
        if (!fname || !loginId || !password || !cpassword) {
            return res.status(500).send({
                success: false,
                message: "plese provide all field"
            })
        }
        //compare password
        if (password !== cpassword) {
                return res.status(500).send({
                success: false,
                message: "please enter both password same"
            })
        }
        //check  user
        const existing = await userModel.findOne({ loginId })
        if (existing) {
            return res.status(500).send({
                success: false,
                message: "Email or Phone no Already Registerd please Login"
            })
        }
        //hashing password
        var salt = bcrypt.genSaltSync(10);
        const hashPassword = await bcrypt.hash(password, salt)
        //create new user
        const user = await userModel.create({ fname, lname, loginId, password: hashPassword})
        user.password = undefined;
        res.status(201).send({
            success: true,
            message: 'Successfully Registered',
            user,
        });

    } catch (error) {
        console.log(error);
        res.status(500).send({
            success: false,
            message: "Error in Register API",
            error
        })
    }
};
//login
const loginController = async (req, res) => {
    try {
        const { loginId, password } = req.body
        //validation
        if (!loginId || !password) {
            return res.status(500).send({
                success: false,
                message: "please provide email and password"
            })

        }
        //check user
        const user = await userModel.findOne({ loginId });
        if (!user) {
            return res.status(404).send({
                success: false,
                message: "user not found",
            });
        }
        //check user password || compare password
        const isMatch = await bcrypt.compare(password, user.password)
        if (!isMatch) {
            return res.status(500).send({
                success: false,
                message: 'password is not matching invalid credentials'
            })
        }
        //create token
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
            expiresIn: '7d',
        });
        user.password = undefined;
        res.status(200).send({
            success: true,
            message: "succesfully logedin",
            token,
            user,
        });
    } catch (error) {
        console.log(error)
        res.status(500).send({
            success: false,
            message: "Error in login API",
            error
        })
    }
}

module.exports = { registerController, loginController }
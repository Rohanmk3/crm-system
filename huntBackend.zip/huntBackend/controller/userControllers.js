const userModel = require("../models/userModel");
const bcrypt = require('bcryptjs')

//get user info
const getAllUsersController = async (req, res) => {
    try {
        // Fetch all users, excluding passwords
        const users = await userModel.find({}, { password: 0 }); // Exclude password field

        // Validation: Check if users exist
        if (!users || users.length === 0) {
            return res.status(404).send({
                success: false,
                message: 'No users found',
            });
        }

        // Response
        res.status(200).send({
            success: true,
            message: 'Users retrieved successfully',
            users,
        });
    } catch (error) {
        console.error(error);
        res.status(500).send({
            success: false,
            message: 'Error retrieving users',
            error,
        });
    }
};



//updateUser
const updateUserController = async (req, res) => {
    try {
        //find user
        const user = await userModel.findById({ _id: req.body.id })
        //validation
        if (!user) {
            return res.status(404).send({
                success: false,
                message: 'user not found'
            })
        }
        //update
        const { fname, address, phone, } = req.body
        if (fname) user.fname = fname
        if (address) user.address = address
        if (phone) user.phone = phone
        //save
        await user.save()
        res.status(200).send({
            success: true,
            message: 'user updated successfully'
        })
    } catch (error) {
        res.status(500).send({
            success: false,
            message: 'error in update api',
            error,
        })
    }
};

//reset password
const resetPasswordController = async (req, res) => {
    try {
        //find user
        const user = await userModel.findById({ _id: req.body.id })
        if (!user) {
            return res.status(404).send({
                success: false,
                message: 'user not found'
            })
        }
        //gett data from user
        const { oldPassword, newPassword } = req.body
        if (!oldPassword || !newPassword) {
            return res.status(500).send({
                success: false,
                message: 'please provide passwords'
            })
        }
        //check user password || compare password
        const isMatch = await bcrypt.compare(oldPassword, user.password)
        if (!isMatch) {
            return res.status(500).send({
                success: false,
                message: 'Invalid old password'
            })
        }
        //hashing password
        var salt = bcrypt.genSaltSync(10);
        const hashPassword = await bcrypt.hash(newPassword, salt)
        user.password = hashPassword
        await user.save()

        res.status(200).send({
            success: true,
            message: "Password updated successfully"
        });

    } catch (error) {
        console.log(error)
        res.status(500).send({
            success: false,
            message: 'error in password update API',
            error,
        })

    }
};

//delete user
const deleteProfileController = async(req,res) => {
    try {
        //find user by id and passing parameters
        await userModel.findByIdAndDelete(req.params.id)
        return res.status(200).send({
            success:true,
            message:'your account has been deleted successfully'
        });
    } catch (error) {
        console.log(error)
        res.status(500).send({
            success:false,
            message:'Error in Delete profile API',
            error,
        })
        
    }
};

module.exports = { getAllUsersController, updateUserController, resetPasswordController, deleteProfileController}
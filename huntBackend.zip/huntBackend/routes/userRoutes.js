const express = require('express');
const {getAllUsersController, resetPasswordController, deleteProfileController } = require('../controller/userControllers');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

//routes
//get user || method name:GET
router.get('/read', getAllUsersController);

//passsword reset
router.post('/resetPassword',authMiddleware, resetPasswordController);

//delete user
router.delete('/deleteProfile/:id', authMiddleware, deleteProfileController)

module.exports = router